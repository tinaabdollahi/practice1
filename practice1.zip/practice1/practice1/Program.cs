﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice1
{
    internal class Program
    {
        static void Main(string[] args)
        {
                double num, mohit, masaht;
                Console.WriteLine("i want to find the diameter and area of a circle. please help me");
                Console.WriteLine("choose a number as radius of the circle:");
                num = Convert.ToDouble(Console.ReadLine());
                mohit = num * num * 3.14;
                masaht = (num * 2) * 3.14;
                Console.WriteLine("area is:{0} \ndiameter is:{1}", mohit, masaht);
                Console.ReadKey();
            }
        }
    }